package com.leitura.app

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable fun Profile(dao: AppDao, ss: List<ReadingSession>, books: List<Book>) {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("profile", 0).also {
        if (!it.contains("since")) it.edit().putLong("since", System.currentTimeMillis()).apply() } }
    var name by remember { mutableStateOf(prefs.getString("name", "") ?: "") }
    var confirm by remember { mutableStateOf(false) }
    val hrs = ss.sumOf { it.durationMs } / 3600000.0
    val pgs = ss.sumOf { it.endPage - it.startPage }
    val done = books.count { it.status == "CONCLUIDO" }
    val medals = listOfNotNull(
        if (ss.isNotEmpty()) "📖 Primeira leitura" else null, if (done >= 1) "📕 Primeiro livro concluído" else null,
        if (hrs >= 10) "⏱ 10 horas" else null, if (hrs >= 100) "🏆 100 horas" else null,
        if (pgs >= 500) "📚 500 páginas" else null)
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(name, { name = it.take(40); prefs.edit().putString("name", name).apply() },
            label = { Text("Seu nome") }, modifier = Modifier.fillMaxWidth())
        Text("No app desde ${SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(prefs.getLong("since", 0)))}")
        Text("Horas lidas: ${"%.1f".format(hrs)} · Páginas: $pgs")
        Text("Livros concluídos: $done · Sessões: ${ss.size}")
        Text("Medalhas: " + if (medals.isEmpty()) "nenhuma ainda" else medals.joinToString(" · "))
        Text("Todos os dados ficam somente neste aparelho.")
        TextButton({ confirm = true }) { Text("Apagar todos os meus dados") }
    }
    if (confirm) AlertDialog(onDismissRequest = { confirm = false }, title = { Text("Apagar tudo?") },
        text = { Text("Remove livros e sessões deste aparelho de forma permanente.") },
        confirmButton = { TextButton({ confirm = false; scope.launch { dao.clearSessions(); dao.clearBooks() } }) { Text("Apagar") } },
        dismissButton = { TextButton({ confirm = false }) { Text("Cancelar") } })
}
