package com.leitura.app

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow
import java.util.UUID

@Entity data class Book(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String, val author: String, val totalPages: Int,
    val currentPage: Int = 0, val status: String = "LENDO")

@Entity data class ReadingSession(
    @PrimaryKey val uuid: String = UUID.randomUUID().toString(),
    val bookId: Long, val startPage: Int, val endPage: Int,
    val durationMs: Long, val startedAt: Long, val note: String = "")

@Dao interface AppDao {
    @Query("DELETE FROM ReadingSession") suspend fun clearSessions()
    @Query("DELETE FROM Book") suspend fun clearBooks()
    @Insert suspend fun addBook(b: Book): Long
    @Query("SELECT * FROM Book ORDER BY title") fun books(): Flow<List<Book>>
    @Query("UPDATE Book SET currentPage=:p, status=CASE WHEN :p>=totalPages AND totalPages>0 THEN 'CONCLUIDO' ELSE status END WHERE id=:id")
    suspend fun setPage(id: Long, p: Int)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun addSession(s: ReadingSession)
    @Query("SELECT * FROM ReadingSession ORDER BY startedAt DESC") fun sessions(): Flow<List<ReadingSession>>
}

@Database(entities = [Book::class, ReadingSession::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): AppDao
    companion object {
        @Volatile private var i: AppDb? = null
        fun get(c: Context) = i ?: synchronized(this) {
            i ?: Room.databaseBuilder(c.applicationContext, AppDb::class.java, "leitura.db").build().also { i = it }
        }
    }
}

/** Estado do cronômetro em SharedPreferences: sobrevive a fechamento do app/processo.
 *  Tempo = acumulado + (agora - retomadoEm). Pausa não conta. */
class Timer(c: Context) {
    private val p = c.getSharedPreferences("timer", Context.MODE_PRIVATE)
    val active get() = p.getLong("bookId", -1) >= 0
    val bookId get() = p.getLong("bookId", -1)
    val startPage get() = p.getInt("startPage", 0)
    val startedAt get() = p.getLong("startedAt", 0)
    val running get() = p.getLong("since", 0) > 0
    fun elapsed(): Long = p.getLong("acc", 0) + if (running) System.currentTimeMillis() - p.getLong("since", 0) else 0
    fun start(book: Long, page: Int) {
        val n = System.currentTimeMillis()
        p.edit().putLong("bookId", book).putInt("startPage", page).putLong("startedAt", n)
            .putLong("acc", 0).putLong("since", n).apply()
    }
    fun pause() { if (running) p.edit().putLong("acc", elapsed()).putLong("since", 0).apply() }
    fun resume() { if (active && !running) p.edit().putLong("since", System.currentTimeMillis()).apply() }
    fun clear() { p.edit().clear().apply() }
}
