package com.leitura.app

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Calendar

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        val dao = AppDb.get(this).dao()
        val timer = Timer(this)
        setContent { MaterialTheme(colorScheme = if (androidx.compose.foundation.isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) { Surface(Modifier.fillMaxSize()) { App(dao, timer) } } }
    }
}

fun fmt(ms: Long): String { val s = ms / 1000; return "%02d:%02d:%02d".format(s / 3600, s / 60 % 60, s % 60) }
fun startOf(field: Int): Long = Calendar.getInstance().apply {
    set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    if (field == Calendar.WEEK_OF_YEAR) set(Calendar.DAY_OF_WEEK, firstDayOfWeek)
}.timeInMillis

@Composable fun App(dao: AppDao, timer: Timer) {
    var tab by remember { mutableIntStateOf(0) }
    val books by dao.books().collectAsState(emptyList())
    val sessions by dao.sessions().collectAsState(emptyList())
    Scaffold(bottomBar = {
        NavigationBar {
            listOf("Início" to Icons.Default.Home, "Livros" to Icons.Default.Book,
                "Ler" to Icons.Default.PlayCircle, "Estatísticas" to Icons.Default.BarChart,
                "Perfil" to Icons.Default.Person)
                .forEachIndexed { i, (l, ic) ->
                    NavigationBarItem(tab == i, { tab = i }, { Icon(ic, l) }, label = { Text(l, maxLines = 1, fontSize = 11.sp) })
                }
        }
    }) { pad ->
        Box(Modifier.padding(pad).padding(16.dp).fillMaxSize()) {
            when (tab) {
                0 -> Home(sessions, books)
                1 -> Library(dao, books)
                2 -> Reader(dao, timer, books)
                3 -> Stats(sessions, books)
                else -> Profile(dao, sessions, books)
            }
        }
    }
}

@Composable fun Home(ss: List<ReadingSession>, books: List<Book>) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("goals", 0) }
    var goal by remember { mutableIntStateOf(prefs.getInt("daily", 30)) }
    val fd = java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.US)
    val dset = ss.map { fd.format(it.startedAt) }.toSet()
    val cal = Calendar.getInstance(); var streak = 0
    if (fd.format(cal.time) !in dset) cal.add(Calendar.DAY_OF_YEAR, -1)
    while (fd.format(cal.time) in dset) { streak++; cal.add(Calendar.DAY_OF_YEAR, -1) }
    val day = ss.filter { it.startedAt >= startOf(Calendar.DAY_OF_YEAR) }.sumOf { it.durationMs }
    val week = ss.filter { it.startedAt >= startOf(Calendar.WEEK_OF_YEAR) }.sumOf { it.durationMs }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Olá, ${ctx.getSharedPreferences("profile", 0).getString("name", "")?.ifBlank { "leitor" }}!", fontSize = 26.sp)
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) { Text("Hoje"); Text(fmt(day), fontSize = 32.sp) } }
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) { Text("Semana"); Text(fmt(week), fontSize = 32.sp) } }
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Meta diária: ${day / 60000}/$goal min · 🔥 $streak dias seguidos")
            LinearProgressIndicator(progress = { (day / 60000f / goal).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(goal.toString(), { v -> v.filter(Char::isDigit).toIntOrNull()?.let { if (it in 1..1440) { goal = it; prefs.edit().putInt("daily", it).apply() } } },
                label = { Text("Meta (min/dia)") })
        } }
        Text("Concluídos: ${books.count { it.status == "CONCLUIDO" }}")
        Text("Últimas leituras", fontSize = 18.sp)
        LazyColumn { items(ss.take(5)) { s ->
            val b = books.find { it.id == s.bookId }
            ListItem(headlineContent = { Text(b?.title ?: "Livro") },
                supportingContent = { Text("${fmt(s.durationMs)} · ${s.endPage - s.startPage} págs") })
        } }
    }
}

@Composable fun Library(dao: AppDao, books: List<Book>) {
    val scope = rememberCoroutineScope()
    var t by remember { mutableStateOf("") }; var a by remember { mutableStateOf("") }; var n by remember { mutableStateOf("") }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(t, { t = it }, label = { Text("Título") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(a, { a = it }, label = { Text("Autor") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(n, { n = it.filter(Char::isDigit) }, label = { Text("Total de páginas") }, modifier = Modifier.fillMaxWidth())
        Button(enabled = t.isNotBlank(), onClick = {
            scope.launch { dao.addBook(Book(title = t, author = a, totalPages = n.toIntOrNull() ?: 0)) }
            t = ""; a = ""; n = ""
        }) { Text("Adicionar livro") }
        LazyColumn { items(books) { b ->
            ListItem(headlineContent = { Text(b.title) },
                supportingContent = { Text("${b.author} · ${b.currentPage}/${b.totalPages} · ${b.status}") })
        } }
    }
}

@Composable fun Reader(dao: AppDao, timer: Timer, books: List<Book>) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var tick by remember { mutableLongStateOf(0) }
    var active by remember { mutableStateOf(timer.active) }
    var page by remember { mutableStateOf("") }
    var finishing by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf("") }
    LaunchedEffect(active) { while (true) { tick = timer.elapsed(); delay(500) } }

    if (!active) {
        var sel by remember { mutableStateOf<Book?>(null) }
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Escolha o livro", fontSize = 20.sp)
            if (books.isEmpty()) Text("Cadastre um livro na aba Livros.")
            LazyColumn(Modifier.weight(1f, false).heightIn(max = 260.dp)) { items(books) { b ->
                ListItem(headlineContent = { Text(b.title) },
                    leadingContent = { RadioButton(sel?.id == b.id, { sel = b; page = b.currentPage.toString() }) })
            } }
            OutlinedTextField(page, { page = it.filter(Char::isDigit) }, label = { Text("Página inicial") })
            Button(enabled = sel != null && page.isNotEmpty(), onClick = {
                timer.start(sel!!.id, page.toInt()); active = true; ReadingService.sync(ctx)
            }) { Text("INICIAR LEITURA") }
        }
    } else {
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(books.find { it.id == timer.bookId }?.title ?: "", fontSize = 18.sp)
            Text(fmt(tick), fontSize = 56.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button({ if (timer.running) timer.pause() else timer.resume(); ReadingService.sync(ctx) }) {
                    Text(if (timer.running) "Pausar" else "Retomar") }
                OutlinedButton({ timer.pause(); page = ""; finishing = true }) { Text("Finalizar") }
            }
        }
    }
    if (finishing) AlertDialog(onDismissRequest = {}, title = { Text("Resumo da sessão") },
        text = { Column {
            Text("Tempo: ${fmt(timer.elapsed())} · página inicial ${timer.startPage}")
            OutlinedTextField(page, { page = it.filter(Char::isDigit) }, label = { Text("Página final") })
            OutlinedTextField(note, { note = it }, label = { Text("Observações (opcional)") })
        } },
        confirmButton = { TextButton(enabled = page.isNotEmpty(), onClick = {
            val end = page.toInt(); val bid = timer.bookId
            val s = ReadingSession(bookId = bid, startPage = timer.startPage, endPage = end,
                durationMs = timer.elapsed(), startedAt = timer.startedAt, note = note)
            scope.launch { dao.addSession(s); dao.setPage(bid, end) }
            timer.clear(); ReadingService.sync(ctx); active = false; finishing = false; note = ""
        }) { Text("Salvar") } },
        dismissButton = { TextButton({ timer.resume(); ReadingService.sync(ctx); finishing = false }) { Text("Voltar a ler") } })
}

@Composable fun Stats(ss: List<ReadingSession>, books: List<Book>) {
    val total = ss.sumOf { it.durationMs }
    val days = ss.map { java.text.SimpleDateFormat("yyyyMMdd").format(it.startedAt) }.distinct().size
    val byDay = ss.groupBy { java.text.SimpleDateFormat("dd/MM/yyyy").format(it.startedAt) }
        .mapValues { it.value.sumOf { s -> s.durationMs } }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Tempo total: ${fmt(total)}")
        Text("Média por sessão: ${if (ss.isEmpty()) "-" else fmt(total / ss.size)}")
        Text("Média por dia de leitura: ${if (days == 0) "-" else fmt(total / days)}")
        Text("Páginas lidas: ${ss.sumOf { it.endPage - it.startPage }}")
        Text("Livros concluídos: ${books.count { it.status == "CONCLUIDO" }}")
        byDay.maxByOrNull { it.value }?.let { Text("Melhor dia: ${it.key} (${fmt(it.value)})") }
        Text("Histórico", fontSize = 18.sp)
        LazyColumn { items(ss) { s -> ListItem(
            headlineContent = { Text(books.find { it.id == s.bookId }?.title ?: "Livro") },
            supportingContent = { Text("${fmt(s.durationMs)} · págs ${s.startPage}→${s.endPage}") }) } }
    }
}
