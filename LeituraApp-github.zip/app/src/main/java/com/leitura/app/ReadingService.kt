package com.leitura.app

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat

/** Foreground Service: mantém o processo vivo e mostra notificação persistente.
 *  O tempo em si vem do Timer (prefs), não do serviço. */
class ReadingService : Service() {
    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val t = Timer(this)
        if (!t.active) { stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return START_NOT_STICKY }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("read", "Leitura", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(this, "read")
            .setSmallIcon(android.R.drawable.ic_menu_agenda)
            .setContentTitle(if (t.running) "Lendo agora" else "Leitura pausada")
            .setOngoing(true).setContentIntent(open).setOnlyAlertOnce(true)
            .apply { if (t.running) { setUsesChronometer(true); setWhen(System.currentTimeMillis() - t.elapsed()) } }
            .build()
        startForeground(1, n)
        return START_STICKY
    }
    companion object { fun sync(c: Context) = c.startForegroundService(Intent(c, ReadingService::class.java)) }
}
