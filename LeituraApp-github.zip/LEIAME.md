# LeituraApp 0.3.0 — 100% local (sem servidor, sem conta, sem comunidade)
Abra a pasta no Android Studio (Koala ou mais novo), aguarde o Gradle sync e use Build > Build APK(s).
Release assinado: Build > Generate Signed Bundle / APK.

Recursos: biblioteca de livros, cronômetro de leitura (Foreground Service, pausa, sobrevive a fechamento do app),
sessões salvas no banco local (Room), estatísticas, meta diária com sequência, medalhas, perfil local, tema claro/escuro.
O app não pede permissão de internet. Todos os dados ficam no aparelho.

Pendente: lembretes agendados, metas semanais/anuais, busca por ISBN, capas, gráficos, exportar/importar backup.

## Se o build falhar
- Use Android Studio Koala (2024.1) ou mais novo, com o JDK embutido (Settings > Build Tools > Gradle > Gradle JDK = jbr-17 ou superior).
- Aceite instalar o Android SDK 34 quando o Studio pedir. Na primeira sincronização é preciso internet (baixa o Gradle e as bibliotecas).
- Abra a pasta `LeituraApp` (a que contém settings.gradle.kts), não a pasta `app`.
- APK de teste: Build > Build APK(s) > "locate". O arquivo fica em app/build/outputs/apk/debug/app-debug.apk.

## Gerar o APK sem Android Studio (GitHub)
1. Crie uma conta e um repositório novo em github.com.
2. Envie o CONTEÚDO da pasta LeituraApp (arquivos na raiz do repositório, incluindo a pasta oculta .github).
3. Aba "Actions" > "Gerar APK" > Run workflow. Ao terminar (uns 5-10 min), abra a execução e baixe "app-debug-apk" em Artifacts.
4. Descompacte e instale o app-debug.apk no celular. Se falhar, abra o log do passo vermelho e me envie o erro.
